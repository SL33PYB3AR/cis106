# Final Submission

## Question 1
![q2](q1.1.png)
## Question 2
![q2](q2.1.png)
## Question 3
![q3](q3.1.png)